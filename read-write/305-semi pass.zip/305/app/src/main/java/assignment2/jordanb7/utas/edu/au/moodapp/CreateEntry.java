package assignment2.jordanb7.utas.edu.au.moodapp;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Map;

public class CreateEntry extends AppCompatActivity {
    EditText title;
    EditText journal;
    String fileName = "file.txt";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_entry);

        title = findViewById(R.id.journal_title_input);
        journal = findViewById(R.id.journal_input);



        Button fin = findViewById(R.id.journal_done_btn);
        fin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent m = new Intent(getApplicationContext(), MainActivity.class);
                saveFile(fileName, title.getText().toString());
                saveFile(fileName, journal.getText().toString());

                Log.d("meep",  title.getText().toString());
                Log.d("yeet",  journal.getText().toString());
               // m.putExtra(fileName, title.getText().toString());
                startActivity(m);
            }
        });

    }

    public void saveFile(String file, String text) {
        try {
            FileOutputStream fl = openFileOutput(file, Context.MODE_PRIVATE);
            fl.write(text.getBytes());
            fl.close();
            Toast.makeText(CreateEntry.this, "saved!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

        public String readFile(String file, String text){
            //String text = "";

            try{
                FileInputStream flt = openFileInput(file);
                //int size = flt.available();
                //byte[] buffer = new byte[size];
               // flt.read(buffer);
               // flt.close();
               // text = new String(buffer);



            }catch (Exception e){
                e.printStackTrace();

            }
            return text;

        }


        }



