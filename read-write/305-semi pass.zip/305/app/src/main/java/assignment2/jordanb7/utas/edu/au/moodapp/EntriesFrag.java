package assignment2.jordanb7.utas.edu.au.moodapp;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;

public class EntriesFrag extends Fragment {
    String fileName = "file.txt";
    TextView title;



    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View f = inflater.inflate(R.layout.frag_entries,container,false);

        title = f.findViewById(R.id.text);


        Button dis = f.findViewById(R.id.display_entry);
        dis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

             title.setText(readFile(fileName));
               // saveFile(fileName, journal.getText().toString());

                Log.d("map",  fileName);
               // Log.d("yeet",  journal.getText().toString());

            }
        });

        return f;
    }

    public String readFile(String file){
        String text = "";

        try{
           FileInputStream flt = getContext().openFileInput(file);
            int size = flt.available();
            byte[] buffer = new byte[size];
            flt.read(buffer);
            flt.close();
            text = new String(buffer);

        }catch (Exception e){
            e.printStackTrace();

        }
        return text;

    }




}
